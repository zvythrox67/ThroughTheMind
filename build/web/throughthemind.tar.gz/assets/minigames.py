import math
import random

import pygame
import ui
from ui import W, H, text, panel
from game import THOUGHTS

class MiniGame:
    title = ""
    help = ""

    def __init__(self):
        self.done = False
        self.result = None
        self.ready = 2.2
        self.t = 0.0
        self.rng = random.Random()

    def finish(self, result):
        self.done = True
        self.result = result

    def event(self, e):
        pass

    def update(self, dt):
        if self.ready > 0:
            self.ready -= dt
            return
        self.t += dt
        self.step(dt)

    def step(self, dt):
        pass

    def draw(self, surf):
        self.render(surf)
        if self.ready > 0:
            ui.tint(surf, (20, 8, 48), 0.6)
            panel(surf, (112, 200, 800, 230), (34, 20, 70, 250))
            text(surf, self.title, (W // 2, 222), 56, ui.YELLOW, center=True)
            for i, ln in enumerate(ui.wrap(self.help, 30, 740)):
                text(surf, ln, (W // 2, 292 + i * 30), 30, center=True)
            text(surf, "Get ready...", (W // 2, 386), 28, ui.LAV_LT, center=True)

    def render(self, surf):
        pass

    def axis(self, neg, pos):
        k = pygame.key.get_pressed()
        return (1 if any(k[p] for p in pos) else 0) - (1 if any(k[n] for n in neg) else 0)

class BreathingGame(MiniGame):
    title = "Breathe"
    help = "Breathe in as the ring closes. Press SPACE when it meets the circle."
    ROUNDS = 5

    def __init__(self, params=None):
        super().__init__()
        params = params or {}
        sev = params.get("sev", 1.0)
        self.period = 3.2 - 0.3 * (sev - 0.7) - (0.5 if params.get("panic") else 0)
        self.window = max(12, 18 - 3 * (sev - 0.7))
        self.panic = params.get("panic", False)
        if self.panic:
            self.title = "Panic: slow your breathing"
        self.round, self.score, self.pressed = 0, 0, False
        self.msg, self.msg_t = "", 0.0

    def ring(self):
        return 220 - 160 * (self.t / self.period)

    def event(self, e):
        if self.ready > 0 or self.done:
            return
        if e.type == pygame.KEYDOWN and e.key == pygame.K_SPACE and not self.pressed:
            self.pressed = True
            if abs(self.ring() - 60) <= self.window:
                self.score += 1
                self.msg = "Good"
            else:
                self.msg = "Off. Slow down."
            self.msg_t = 1.0

    def step(self, dt):
        self.msg_t -= dt
        if self.t >= self.period:
            if not self.pressed:
                self.msg, self.msg_t = "Missed. Breathe with the ring.", 1.0
            self.round += 1
            self.t = 0.0
            self.pressed = False
            if self.round >= self.ROUNDS:
                self.finish({"score": self.score})

    def render(self, surf):
        surf.fill(ui.INDIGO_DK)
        for i in range(30):
            pygame.draw.rect(surf, ui.YELLOW, ((i * 197) % W, (i * 89) % H, 3, 3))
        text(surf, "Breath %d of %d" % (min(self.round + 1, self.ROUNDS), self.ROUNDS), (W // 2, 90), 40, center=True)
        cx, cy = W // 2, H // 2 + 20
        pygame.draw.circle(surf, ui.PINK, (cx, cy), 60, 5)
        r = int(max(10, self.ring()))
        pygame.draw.circle(surf, ui.CREAM, (cx, cy), r, 6)
        if self.msg_t > 0:
            text(surf, self.msg, (cx, H - 100), 44, ui.YELLOW, center=True)

class FocusGame(MiniGame):
    title = "Stay focused"
    help = "Move with A / D or the arrow keys. Catch the green answers. Dodge the pink worry clouds."

    def __init__(self, params):
        super().__init__()
        sev = params.get("sev", 1.0)
        self.exam = params.get("exam", False)
        if self.exam:
            self.title = "The big exam"
        self.duration = 28.0 if self.exam else 24.0
        self.cloud_p = min(0.8, 0.26 + 0.35 * params.get("worry", 50) / 100 + 0.09 * (sev - 0.7) + (0.08 if self.exam else 0))
        self.fall = 0.85 + 0.2 * sev
        self.px = W / 2
        self.items = []
        self.spawn = 0.0
        self.good = self.good_total = self.hits = 0
        self.stun = self.flash = 0.0
        self.facing = "east"

    def step(self, dt):
        dx = self.axis((pygame.K_a, pygame.K_LEFT), (pygame.K_d, pygame.K_RIGHT))
        if dx:
            self.facing = "east" if dx > 0 else "west"
        speed = 340 * (0.45 if self.stun > 0 else 1.0)
        self.px = max(80, min(W - 80, self.px + dx * speed * dt))
        self.stun = max(0.0, self.stun - dt)
        self.flash = max(0.0, self.flash - dt)
        self.spawn -= dt
        if self.spawn <= 0 and self.t < self.duration - 2.5:
            self.spawn = 0.55
            cloud = self.rng.random() < self.cloud_p
            if not cloud:
                self.good_total += 1
            self.items.append({"x": self.rng.uniform(80, W - 80), "y": -30.0,
                               "vy": (self.rng.uniform(170, 230) + self.t * 3) * self.fall,
                               "cloud": cloud, "txt": self.rng.choice(THOUGHTS)})
        player = (self.px - 36, H - 190, 72, 130)
        for it in self.items[:]:
            it["y"] += it["vy"] * dt
            hit = player[0] - 20 < it["x"] < player[0] + player[2] + 20 and player[1] < it["y"] < player[1] + player[3]
            if hit:
                self.items.remove(it)
                if it["cloud"]:
                    self.hits += 1
                    self.stun, self.flash = 0.8, 0.3
                else:
                    self.good += 1
            elif it["y"] > H:
                self.items.remove(it)
        if self.t >= self.duration:
            self.finish({"score": self.good / max(1, self.good_total), "hits": self.hits})

    def render(self, surf):
        surf.fill((104, 82, 170))
        pygame.draw.rect(surf, ui.INDIGO, (0, H - 60, W, 60))
        pygame.draw.rect(surf, ui.LAV_LT, (0, H - 64, W, 4))
        pygame.draw.rect(surf, ui.CREAM, (200, 40, 624, 90))
        pygame.draw.rect(surf, ui.PINK, (200, 40, 624, 90), 4)
        text(surf, "The exam" if self.exam else "The lesson", (W // 2, 70), 44, ui.INDIGO, center=True)
        for dx in (120, 330, 560, 780):
            pygame.draw.rect(surf, (214, 160, 140), (dx, H - 100, 120, 40))
            pygame.draw.rect(surf, (150, 100, 110), (dx, H - 100, 120, 40), 3)
        for it in self.items:
            x, y = int(it["x"]), int(it["y"])
            if it["cloud"]:
                for ox in (-18, 0, 18):
                    pygame.draw.circle(surf, ui.PINK, (x + ox, y), 20)
                pygame.draw.rect(surf, ui.BLUE, (x - 36, y + 12, 72, 8))
                text(surf, it["txt"], (x, y + 28), 20, ui.CREAM, center=True, shadow=True)
            else:
                pygame.draw.rect(surf, ui.GOOD, (x - 28, y - 20, 56, 40))
                pygame.draw.rect(surf, (40, 120, 100), (x - 28, y - 20, 56, 40), 3)
                text(surf, "A+", (x, y - 8), 28, ui.INDIGO_DK, center=True)
        img = ui.sprite(ui.HERO, self.facing, 3)
        w, h = img.get_size()
        surf.blit(img, (int(self.px - w / 2), H - 60 - h + 10))
        if self.flash > 0:
            ui.tint(surf, (251, 107, 162), self.flash)
        left = max(0.0, self.duration - self.t)
        pygame.draw.rect(surf, ui.INDIGO, (330, 150, 364, 14))
        pygame.draw.rect(surf, ui.GOOD, (330, 150, int(364 * left / self.duration), 14))
        pygame.draw.rect(surf, ui.LAV_LT, (330, 150, 364, 14), 2)
        text(surf, "Caught %d     Worries hit %d" % (self.good, self.hits), (W // 2, 176), 30, ui.CREAM, center=True, shadow=True)

class VoiceGame(MiniGame):
    title = "Steady voice"
    help = "Hold LEFT or RIGHT to keep the dot inside the zone while you present. The audience's attention makes your voice shake."
    DURATION = 20.0

    def __init__(self, params):
        super().__init__()
        sev = params.get("sev", 1.0)
        self.tremor = (1.0 + 1.6 * params.get("worry", 50) / 100 + (0.6 if params.get("presenting") else 0)) * (0.7 + 0.4 * sev)
        self.x = 0.0
        self.v = 0.0
        self.in_zone = 0.0
        self.spike = 0.0
        self.next_spike = 4.0

    def step(self, dt):
        dx = self.axis((pygame.K_a, pygame.K_LEFT), (pygame.K_d, pygame.K_RIGHT))
        self.next_spike -= dt
        if self.next_spike <= 0:
            self.spike, self.next_spike = 1.5, self.rng.uniform(4, 6)
        self.spike = max(0.0, self.spike - dt)
        k = self.tremor * (2.0 if self.spike > 0 else 1.0)
        self.v += self.rng.uniform(-1, 1) * k * dt * 6 + dx * dt * 5.5
        self.v *= max(0.0, 1 - 0.9 * dt)
        self.x = max(-1.2, min(1.2, self.x + self.v * dt))
        if abs(self.x) < 0.22:
            self.in_zone += dt
        if self.t >= self.DURATION:
            self.finish({"score": self.in_zone / self.DURATION})

    def render(self, surf):
        surf.fill(ui.INDIGO_DK)
        mx = W // 2 + self.x * 300
        wide = 1.0 + (0.5 if self.spike > 0 else 0.0)
        for i in range(9):
            ui.draw_eye(surf, 110 + i * 100, 110 + (i % 2) * 40, 26 * wide, 0.9, mx, 380)
        pygame.draw.polygon(surf, ui.INDIGO, [(W // 2 - 60, 200), (W // 2 + 60, 200), (W // 2 + 220, H), (W // 2 - 220, H)])
        pygame.draw.rect(surf, (176, 112, 120), (W // 2 - 90, 520, 180, 90))
        pygame.draw.rect(surf, (214, 160, 140), (W // 2 - 90, 520, 180, 14))
        img = ui.sprite(ui.HERO, "north", 3)
        surf.blit(img, (W // 2 - img.get_width() // 2, 400))
        pygame.draw.rect(surf, ui.INDIGO, (W // 2 - 330, 300, 660, 40))
        pygame.draw.rect(surf, ui.LAV, (W // 2 - 330, 300, 660, 40), 3)
        zone_w = int(0.44 * 300)
        pygame.draw.rect(surf, ui.GOOD, (W // 2 - zone_w, 304, zone_w * 2, 32))
        inside = abs(self.x) < 0.22
        pygame.draw.circle(surf, ui.YELLOW if inside else ui.PINK, (int(mx), 320), 18)
        pygame.draw.circle(surf, ui.INDIGO_DK, (int(mx), 320), 18, 3)
        text(surf, "Your voice", (W // 2, 262), 34, center=True)
        left = max(0.0, self.DURATION - self.t)
        text(surf, "%d s left" % math.ceil(left), (W - 30, 20), 32, right=True)
        text(surf, "Steady: %d%%" % round(100 * self.in_zone / max(0.1, self.t)), (30, 20), 32)

class CheckGame(MiniGame):
    title = "Homework"
    help = "Type each answer and press Enter. Then choose: R to re-check, or SPACE to trust yourself and move on."

    def __init__(self, params):
        super().__init__()
        r = self.rng
        self.qs = []
        for i in range(5):
            if i % 2 == 0:
                a, b = r.randint(12, 49), r.randint(12, 49)
                self.qs.append(("%d + %d" % (a, b), a + b))
            else:
                a, b = r.randint(3, 9), r.randint(6, 12)
                self.qs.append(("%d x %d" % (a, b), a * b))
        self.q = 0
        self.input = ""
        self.state = "answer"
        self.rechecks = self.trusted = self.correct = self.q_checks = 0
        self.msg = ""

    def event(self, e):
        if self.ready > 0 or self.done or e.type != pygame.KEYDOWN:
            return
        if self.state == "answer":
            if pygame.K_0 <= e.key <= pygame.K_9 and len(self.input) < 4:
                self.input += chr(e.key)
            elif e.key == pygame.K_BACKSPACE:
                self.input = self.input[:-1]
            elif e.key == pygame.K_RETURN and self.input:
                self.state = "decide"
                self.msg = ""
        elif self.state == "decide":
            if e.key == pygame.K_r:
                self.rechecks += 1
                self.q_checks += 1
                ok = int(self.input) == self.qs[self.q][1]
                self.msg = ("Re-checking... same answer. It was right. (The doubt will come back.)" if ok
                            else "Re-checking... something looks off. Maybe change it?")
                self.state = "answer"
                if not ok:
                    self.input = ""
            elif e.key == pygame.K_SPACE:
                if int(self.input) == self.qs[self.q][1]:
                    self.correct += 1
                if self.q_checks == 0:
                    self.trusted += 1
                self.q += 1
                self.input, self.q_checks, self.msg, self.state = "", 0, "", "answer"
                if self.q >= len(self.qs):
                    self.finish({"correct": self.correct, "rechecks": self.rechecks, "trusted": self.trusted})

    def render(self, surf):
        surf.fill(ui.CREAM)
        for y in range(120, H, 36):
            pygame.draw.line(surf, (190, 175, 235), (0, y), (W, y), 1)
        pygame.draw.line(surf, ui.PINK, (110, 0), (110, H), 3)
        if self.q >= len(self.qs):
            return
        text(surf, "Question %d of %d" % (self.q + 1, len(self.qs)), (150, 40), 36, ui.VIOLET)
        text(surf, self.qs[self.q][0] + " = ?", (150, 150), 92, ui.INDIGO)
        pygame.draw.rect(surf, ui.WHITE, (150, 280, 260, 70))
        pygame.draw.rect(surf, ui.VIOLET, (150, 280, 260, 70), 4)
        text(surf, self.input + ("_" if self.state == "answer" and int(self.t * 2) % 2 == 0 else ""), (170, 292), 66, ui.INDIGO)
        if self.state == "decide":
            panel(surf, (150, 390, 724, 140), (46, 27, 91, 245))
            text(surf, "What if it's wrong?", (180, 405), 46, ui.YELLOW)
            text(surf, "R  =  re-check it        SPACE  =  trust yourself and move on", (180, 470), 32)
        elif self.msg:
            text(surf, self.msg, (150, 400), 28, ui.PINK)
        else:
            text(surf, "Type your answer, then press Enter.", (150, 400), 28, ui.LAV_DK)
        text(surf, "Re-checks: %d" % self.rechecks, (W - 40, 40), 32, ui.PINK, right=True)

class DecisionGame(MiniGame):
    title = "Where do you sit?"
    help = "Press 1, 2 or 3 (or click a card). The longer you wait, the more 'what ifs' pile up."
    OPTIONS = [
        ("Sit at the friends' table", ["What if I have nothing to say?", "What if they stop talking when I sit down?"]),
        ("Take a tray to the quiet corner", ["What if they think I'm avoiding them?", "What if I look like a loner?"]),
        ("Skip lunch", ["What if I get lightheaded later?", "What if everyone notices I didn't eat?"]),
    ]

    def __init__(self, params):
        super().__init__()
        self.rate = (0.07 + 0.12 * params.get("worry", 50) / 100) * (0.75 + 0.35 * params.get("sev", 1.0))
        self.spiral = 0.0
        self.cards = [(52 + i * 316, 230, 296, 240) for i in range(3)]

    def pick(self, i):
        self.finish({"choice": i, "spiral": min(1.0, self.spiral)})

    def event(self, e):
        if self.ready > 0 or self.done:
            return
        if e.type == pygame.KEYDOWN and pygame.K_1 <= e.key <= pygame.K_3:
            self.pick(e.key - pygame.K_1)
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i, r in enumerate(self.cards):
                if r[0] <= e.pos[0] <= r[0] + r[2] and r[1] <= e.pos[1] <= r[1] + r[3]:
                    self.pick(i)

    def step(self, dt):
        self.spiral += self.rate * dt
        if self.spiral >= 1.0:
            self.finish({"choice": 2, "spiral": 1.0})  # froze: the bell rang

    def render(self, surf):
        surf.fill((91, 68, 154))
        for i in range(0, W, 48):
            pygame.draw.polygon(surf, (ui.PINK, ui.YELLOW, ui.CORAL, ui.BLUE)[(i // 48) % 4], [(i, 0), (i + 28, 0), (i + 14, 34)])
        text(surf, "Lunch.  Where do you sit?", (W // 2, 70), 58, ui.CREAM, center=True, shadow=True)
        pygame.draw.rect(surf, ui.INDIGO, (262, 130, 500, 18))
        col = ui.GOOD if self.spiral < 0.4 else ui.YELLOW if self.spiral < 0.7 else ui.PINK
        pygame.draw.rect(surf, col, (262, 130, max(6, int(500 * self.spiral)), 18))
        pygame.draw.rect(surf, ui.LAV_LT, (262, 130, 500, 18), 2)
        text(surf, "Thought spiral", (W // 2, 160), 30, ui.CREAM, center=True)
        shake = self.spiral * 5
        for i, (r, (label, risks)) in enumerate(zip(self.cards, self.OPTIONS)):
            ox = int(math.sin(self.t * 31 + i) * shake)
            oy = int(math.cos(self.t * 27 + i) * shake)
            x, y, w, h = r[0] + ox, r[1] + oy, r[2], r[3]
            pygame.draw.rect(surf, ui.INDIGO_DK, (x + 5, y + 7, w, h))
            pygame.draw.rect(surf, ui.CREAM, (x, y, w, h))
            pygame.draw.rect(surf, ui.PINK, (x, y, w, h), 4)
            text(surf, str(i + 1), (x + 16, y + 10), 58, ui.PINK)
            for j, ln in enumerate(ui.wrap(label, 32, w - 30)):
                text(surf, ln, (x + 16, y + 62 + j * 28), 32, ui.INDIGO)
            for j, risk in enumerate(risks):
                if self.spiral > 0.2 + 0.25 * j:
                    for k, ln in enumerate(ui.wrap(risk, 24, w - 30)):
                        text(surf, ln, (x + 16, y + 130 + j * 56 + k * 22), 24, (190, 60, 110))
        for n in range(int(self.spiral * 7)):
            t = THOUGHTS[n % len(THOUGHTS)]
            text(surf, t, (60 + (n * 211) % 700, 510 + (n * 37) % 90), 26, ui.CORAL, shadow=True)

class SortGame(MiniGame):
    title = "Worry sorting"
    help = "A counseling skill: is this worry something you can control? LEFT = I can do something. RIGHT = I can't control it."
    CAN = ["Studying for the quiz tonight", "Asking a friend to hang out", "How much sleep I get", "Practicing my presentation",
           "Taking a walk after school", "Asking the teacher a question"]
    CANT = ["Whether it rains on Saturday", "What other people think of me", "Whether the test will be hard",
            "What happens ten years from now", "My friend being in a bad mood", "Things that haven't happened yet"]

    def __init__(self, params=None):
        super().__init__()
        cards = [(t, True) for t in self.rng.sample(self.CAN, 4)] + [(t, False) for t in self.rng.sample(self.CANT, 4)]
        self.rng.shuffle(cards)
        self.cards = cards
        self.i = 0
        self.score = 0
        self.fb = ""
        self.fb_t = 0.0
        self.fb_ok = True

    def event(self, e):
        if self.ready > 0 or self.done or self.fb_t > 0 or e.type != pygame.KEYDOWN:
            return
        if e.key in (pygame.K_LEFT, pygame.K_a):
            ans = True
        elif e.key in (pygame.K_RIGHT, pygame.K_d):
            ans = False
        else:
            return
        truth = self.cards[self.i][1]
        self.fb_ok = ans == truth
        if self.fb_ok:
            self.score += 1
        if self.fb_ok:
            self.fb = "Yes. You can take a step on this." if truth else "Right. This is outside your control. You can let it be."
        else:
            self.fb = "Not quite. You actually can do something about this." if truth else "Not quite. You can't control this one."
        self.fb_t = 1.4

    def step(self, dt):
        if self.fb_t > 0:
            self.fb_t -= dt
            if self.fb_t <= 0:
                self.i += 1
                if self.i >= len(self.cards):
                    self.finish({"score": self.score / len(self.cards)})

    def render(self, surf):
        surf.fill(ui.INDIGO)
        pygame.draw.rect(surf, (60, 150, 140), (0, 0, 300, H))
        pygame.draw.rect(surf, ui.VIOLET, (W - 300, 0, 300, H))
        text(surf, "I CAN", (150, 180), 56, ui.CREAM, center=True, shadow=True)
        text(surf, "do something", (150, 232), 36, ui.CREAM, center=True, shadow=True)
        text(surf, "I CAN'T", (W - 150, 180), 56, ui.CREAM, center=True, shadow=True)
        text(surf, "control it", (W - 150, 232), 36, ui.CREAM, center=True, shadow=True)
        text(surf, "<  LEFT", (150, 560), 38, ui.YELLOW, center=True)
        text(surf, "RIGHT  >", (W - 150, 560), 38, ui.YELLOW, center=True)
        if self.i < len(self.cards):
            pygame.draw.rect(surf, ui.CREAM, (350, 200, 324, 220))
            pygame.draw.rect(surf, ui.PINK, (350, 200, 324, 220), 5)
            for j, ln in enumerate(ui.wrap(self.cards[self.i][0], 38, 290)):
                text(surf, ln, (W // 2, 250 + j * 40), 38, ui.INDIGO, center=True)
            text(surf, "Worry %d of %d" % (self.i + 1, len(self.cards)), (W // 2, 120), 38, ui.CREAM, center=True)
        if self.fb_t > 0:
            for j, ln in enumerate(ui.wrap(self.fb, 30, 640)):
                text(surf, ln, (W // 2, 470 + j * 30), 30, ui.GOOD if self.fb_ok else ui.PINK, center=True, shadow=True)

class SleepGame(MiniGame):
    title = "Racing thoughts"
    help = "You can't fall asleep. Move the glow with the arrow keys / WASD and pop each worry before it reaches your pillow."
    DURATION = 22.0
    TEXTS = THOUGHTS + ["What if I oversleep?", "Did I say something weird?", "Tomorrow...", "What if I can't sleep?"]

    def __init__(self, params):
        super().__init__()
        sev = params.get("sev", 1.0)
        self.rate = max(0.34, 0.95 - 0.3 * params.get("worry", 50) / 100 - 0.14 * (sev - 0.7))
        self.speed = 0.85 + 0.2 * sev
        self.cx, self.cy = W / 2, H / 2
        self.px, self.py = W / 2, H / 2 + 150
        self.bubbles = []
        self.spawn = 0.3
        self.popped = self.missed = 0
        self.flash = 0.0

    def step(self, dt):
        dx = self.axis((pygame.K_a, pygame.K_LEFT), (pygame.K_d, pygame.K_RIGHT))
        dy = self.axis((pygame.K_w, pygame.K_UP), (pygame.K_s, pygame.K_DOWN))
        if dx and dy:
            dx, dy = dx * 0.7071, dy * 0.7071
        self.px = max(30, min(W - 30, self.px + dx * 340 * dt))
        self.py = max(30, min(H - 30, self.py + dy * 340 * dt))
        self.flash = max(0.0, self.flash - dt)
        self.spawn -= dt
        if self.spawn <= 0 and self.t < self.DURATION - 3:
            self.spawn = self.rate
            ang = self.rng.uniform(0, 2 * math.pi)
            self.bubbles.append({"x": self.cx + math.cos(ang) * 520, "y": self.cy + math.sin(ang) * 400,
                                 "sp": self.rng.uniform(55, 85) * self.speed, "txt": self.rng.choice(self.TEXTS)})
        for b in self.bubbles[:]:
            dx2, dy2 = self.cx - b["x"], self.cy - b["y"]
            d = math.hypot(dx2, dy2)
            b["x"] += dx2 / d * b["sp"] * dt
            b["y"] += dy2 / d * b["sp"] * dt
            if math.hypot(b["x"] - self.px, b["y"] - self.py) < 52:
                self.bubbles.remove(b)
                self.popped += 1
            elif d < 50:
                self.bubbles.remove(b)
                self.missed += 1
                self.flash = 0.35
        if self.t >= self.DURATION:
            self.missed += len(self.bubbles)
            self.finish({"score": self.popped / max(1, self.popped + self.missed)})

    def render(self, surf):
        surf.fill(ui.INDIGO_DK)
        for i in range(44):
            sx, sy = (i * 197) % W, (i * 89) % H
            pygame.draw.rect(surf, ui.YELLOW, (sx, sy, 3, 3))
            if i % 3 == 0:
                pygame.draw.rect(surf, ui.YELLOW, (sx - 2, sy + 1, 7, 1))
                pygame.draw.rect(surf, ui.YELLOW, (sx + 1, sy - 2, 1, 7))
        pygame.draw.rect(surf, ui.VIOLET, (W // 2 - 150, H // 2 - 120, 300, 240))
        pygame.draw.rect(surf, ui.LAV_LT, (W // 2 - 150, H // 2 - 120, 300, 240), 4)
        pygame.draw.rect(surf, ui.PINK, (W // 2 - 140, H // 2 - 10, 280, 120))
        pygame.draw.rect(surf, ui.CREAM, (W // 2 - 70, H // 2 - 100, 140, 70))
        img = ui.sprite(ui.HERO, "south", 3)
        surf.blit(img, (W // 2 - img.get_width() // 2, H // 2 - 70))
        for b in self.bubbles:
            x, y = int(b["x"]), int(b["y"])
            pygame.draw.circle(surf, ui.LAV_DK, (x, y), 34)
            pygame.draw.circle(surf, ui.LAV_LT, (x, y), 34, 3)
            for j, ln in enumerate(ui.wrap(b["txt"], 18, 100)[:3]):
                text(surf, ln, (x, y - 14 + j * 15), 18, ui.TEXT, center=True)
        pygame.draw.circle(surf, ui.YELLOW, (int(self.px), int(self.py)), 26, 4)
        pygame.draw.circle(surf, ui.CREAM, (int(self.px), int(self.py)), 10)
        if self.flash > 0:
            ui.tint(surf, (251, 107, 162), self.flash)
        text(surf, "Popped %d     Kept you awake %d" % (self.popped, self.missed), (W // 2, 24), 34, center=True)
        left = max(0.0, self.DURATION - self.t)
        pygame.draw.rect(surf, ui.INDIGO, (330, 62, 364, 10))
        pygame.draw.rect(surf, ui.YELLOW, (330, 62, int(364 * left / self.DURATION), 10))

FACTORY = {"breathing": BreathingGame, "focus": FocusGame, "voice": VoiceGame, "check": CheckGame,
           "decision": DecisionGame, "sort": SortGame, "sleep": SleepGame}

def make(kind, params):
    return FACTORY[kind](params)